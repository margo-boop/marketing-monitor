#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="${PYTHON:-python3}"

if [ -x "/Users/a8800/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3" ]; then
  PY="/Users/a8800/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
fi

cd "$ROOT"
exec "$PY" app.py
