@echo off
chcp 65001 >nul
title Маркетинговый мониторинг конкурентов
cd /d "%~dp0"

echo.
echo ====================================================
echo    Маркетинговый мониторинг конкурентов — запуск
echo ====================================================
echo.

REM --- 1. Проверяем Python ---
set PY=
where python >nul 2>nul && set PY=python
if not defined PY where py >nul 2>nul && set PY=py
if not defined PY (
  echo Python не найден на этом компьютере.
  echo Откройте https://www.python.org/downloads/ установите Python,
  echo при установке поставьте галочку "Add Python to PATH",
  echo затем снова запустите этот файл.
  echo.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)
echo [1/3] Python найден.

REM --- 2. Окружение + библиотека для PDF (без неё будет только HTML) ---
if not exist ".venv" (
  echo [2/3] Создаю рабочее окружение (один раз)...
  %PY% -m venv .venv >nul 2>nul
)
if exist ".venv\Scripts\python.exe" set PY=.venv\Scripts\python.exe
%PY% -c "import reportlab" >nul 2>nul || (
  echo [2/3] Доустанавливаю библиотеку для PDF...
  %PY% -m pip install --quiet --upgrade pip >nul 2>nul
  %PY% -m pip install --quiet reportlab >nul 2>nul
)
echo [2/3] Зависимости готовы.

REM --- 3. Браузер + сервер ---
echo [3/3] Запускаю. Браузер откроется автоматически...
echo.
echo   Если не открылся — смотрите адрес ниже и введите его в браузере.
echo   Чтобы остановить — закройте это окно.
echo.
%PY% app.py
pause
