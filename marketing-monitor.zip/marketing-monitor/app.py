#!/usr/bin/env python3
import csv
import hashlib
import html
import io
import json
import os
import re
import ssl
import struct
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import (
        Image,
        KeepTogether,
        ListFlowable,
        ListItem,
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )
except Exception:
    colors = None


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
OUT = ROOT / "output"
REPORTS = OUT / "reports"
ASSETS = OUT / "assets"
STATE_FILE = ROOT / "data" / "state.json"


COMPETITORS = [
    {
        "key": "checkoffice",
        "name": "CheckOffice",
        "domain": "checkoffice.ru",
        "site": "https://checkoffice.ru",
        "queries": ["check office", "чек офис", "checkoffice", "чекофис"],
    },
    {
        "key": "mdaudit",
        "name": "MD Audit",
        "domain": "mdaudit.ru",
        "site": "https://mdaudit.ru",
        "queries": ["мд аудит", "md audit"],
    },
    {
        "key": "serviceinspector",
        "name": "Service Inspector",
        "domain": "serviceinspector.ru",
        "site": "https://serviceinspector.ru",
        "queries": ["сервис инспектор", "service inspector"],
    },
    {
        "key": "retailiqa",
        "name": "Ритейлика",
        "domain": "retailiqa.ru",
        "site": "https://retailiqa.ru",
        "queries": ["ритейлика"],
    },
    {
        "key": "merasoft",
        "name": "Мерасофт",
        "domain": "mera-soft.ru",
        "site": "https://mera-soft.ru",
        "queries": ["мерасофт", "мерасофт чек лист"],
    },
    {
        "key": "imredi",
        "name": "Imredi",
        "domain": "imredi.biz",
        "site": "https://imredi.biz",
        "queries": ["имреди", "imredi"],
    },
]


MONTHS = {
    "feb": "Февраль 2026",
    "mar": "Март 2026",
    "apr": "Апрель 2026",
    "may": "Май 2026",
    "jun": "Июнь 2026",
}


@dataclass
class CompetitorData:
    key: str
    name: str
    domain: str
    site: str
    wordstat: dict = field(default_factory=dict)
    spywords: dict = field(default_factory=lambda: {
        "yandex_top50": None,
        "yandex_top10": None,
        "google_top50": None,
        "google_top10": None,
        "search_traffic_yandex": None,
        "search_traffic_google": None,
        "unique_urls_yandex": None,
        "unique_urls_google": None,
    })
    site_summary: str = ""
    content: list = field(default_factory=list)
    external: list = field(default_factory=list)
    social: list = field(default_factory=list)
    media: list = field(default_factory=list)
    emails: list = field(default_factory=list)
    phones: list = field(default_factory=list)
    events: list = field(default_factory=list)
    updates: list = field(default_factory=list)
    jobs: list = field(default_factory=list)
    images: list = field(default_factory=list)
    errors: list = field(default_factory=list)


def ensure_dirs():
    for path in (ROOT / "data", REPORTS, ASSETS):
        path.mkdir(parents=True, exist_ok=True)


def read_state():
    ensure_dirs()
    if not STATE_FILE.exists():
        return {"sources": {}, "runs": {}}
    try:
        return json.loads(STATE_FILE.read_text("utf-8"))
    except Exception:
        return {"sources": {}, "runs": {}}


def write_state(state):
    ensure_dirs()
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), "utf-8")


def clean_text(value):
    return re.sub(r"\s+", " ", html.unescape(value or "")).strip()


def norm(value):
    value = clean_text(value).lower()
    value = re.sub(r"[«»\"'`]", "", value)
    value = re.sub(r"[^a-zа-яё0-9 ]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def number_from(value):
    matches = re.findall(r"(\d[\d\s\u00a0.,]*)", value or "")
    if not matches:
        return None
    raw = matches[-1].replace("\u00a0", " ").replace(" ", "")
    raw = raw.replace(",", ".")
    try:
        return int(float(raw))
    except Exception:
        return None


def _is_cert_error(exc):
    reason = getattr(exc, "reason", exc)
    if isinstance(reason, ssl.SSLError):
        return True
    return "CERTIFICATE_VERIFY_FAILED" in str(reason) or "certificate" in str(reason).lower()


def urlopen_with_ssl_fallback(req, timeout):
    """Обычная загрузка; если сертификат сайта просрочен/невалиден —
    повторяем без проверки сертификата."""
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.URLError as exc:
        if not _is_cert_error(exc):
            raise
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return urllib.request.urlopen(req, timeout=timeout, context=ctx)


def request_text(url, timeout=12, extra_headers=None):
    headers = {
        "User-Agent": "Mozilla/5.0 MarketingMonitor/1.0 (+local report generator)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    if extra_headers:
        headers.update({k: v for k, v in extra_headers.items() if v})
    req = urllib.request.Request(
        url,
        headers=headers,
    )
    with urlopen_with_ssl_fallback(req, timeout=timeout) as resp:
        raw = resp.read(2_500_000)
        ctype = resp.headers.get_content_charset() or "utf-8"
    return raw.decode(ctype, errors="replace")


def abs_url(url, base):
    try:
        return urllib.parse.urljoin(base, url)
    except Exception:
        return url


def strip_noise(markup):
    """Убираем скрипты и стили, чтобы CSS/JS не попадал в текст ссылок и контент."""
    markup = re.sub(r"<script\b[^>]*>.*?</script>", " ", markup, flags=re.I | re.S)
    markup = re.sub(r"<style\b[^>]*>.*?</style>", " ", markup, flags=re.I | re.S)
    markup = re.sub(r"<!--.*?-->", " ", markup, flags=re.S)
    return markup


def parse_title_description(markup):
    title = ""
    match = re.search(r"<title[^>]*>(.*?)</title>", markup, re.I | re.S)
    if match:
        title = clean_text(re.sub(r"<[^>]+>", " ", match.group(1)))
    desc = ""
    for pattern in [
        r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']',
        r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\'](.*?)["\']',
    ]:
        match = re.search(pattern, markup, re.I | re.S)
        if match:
            desc = clean_text(match.group(1))
            break
    return title, desc


CONTENT_HINT = re.compile(
    r"blog|news|article|articles|stati|statya|post|posts|case|cases|keys|press|media|"
    r"tpost|event|events|webinar|vebinar|efir|update|релиз|release|changelog|nov|новост|"
    r"стат|кейс|обновлен|анонс|материал|guide|how|faq|partner|integration|интеграц",
    re.I,
)
SOCIAL_HINT = re.compile(r"(t\.me|telegram\.me|vk\.com|youtube\.com|youtu\.be|dzen\.ru|zen\.yandex|rutube\.ru|ok\.ru|instagram\.com|facebook\.com|linkedin\.com)", re.I)

JUNK_HREF = re.compile(r"#(popup|menu|submenu|demo|newsletter|question|card|rec|tab|form|b\d)", re.I)
JUNK_PATH = re.compile(r"(personal_data|pd_policy|pd_consent|/policy|/privacy|/oferta|/agreement|/cookie|/sitemap)", re.I)
GENERIC_TEXT = {
    "перезвоните мне", "подписаться на рассылку", "подписаться", "запросить демо",
    "задать вопрос", "получить консультацию", "тестовый доступ", "смотреть кейс",
    "читать кейс", "подробнее", "зарегистрироваться", "скачать", "скачать сейчас",
    "регистрация", "заказать звонок", "узнать больше", "оставить заявку", "связаться",
    "начать", "попробовать", "демо", "войти", "материалы", "чек-листы", "далее",
    "все статьи", "все новости", "все кейсы", "перейти", "читать далее", "читать",
}


def reg_domain(url):
    try:
        netloc = urllib.parse.urlparse(url).netloc.lower().split(":")[0]
    except Exception:
        return ""
    parts = netloc.replace("www.", "").split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else netloc


def slug_title(href):
    path = urllib.parse.urlparse(href).path.rstrip("/")
    seg = path.split("/")[-1] if path else ""
    seg = re.sub(r"\.(html?|php|aspx?|pdf)$", "", seg, flags=re.I)
    seg = re.sub(r"[-_]+", " ", seg).strip()
    if not seg:
        return ""
    return seg[:1].upper() + seg[1:]


def parse_links(markup, base):
    """Возвращает {'content': [...], 'external': [...]} — свой контент и сторонние ресурсы."""
    markup = strip_noise(markup)
    base_dom = reg_domain(base)
    content, external = [], []
    seen = set()
    for match in re.finditer(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', markup, re.I | re.S):
        raw = match.group(1)
        href = abs_url(raw, base)
        if not href.startswith("http"):
            continue
        if JUNK_HREF.search(href) or JUNK_PATH.search(href):
            continue
        bare = href.split("#")[0]
        text = clean_text(re.sub(r"<[^>]+>", " ", match.group(2)))
        if "{" in text or "}" in text or ("px" in text and ":" in text):
            continue  # просочившийся CSS
        ntext = text.lower()
        if len(text) < 8 or ntext in GENERIC_TEXT:
            title = slug_title(bare)
            if not title or len(title) < 6:
                continue  # кнопка без смысла — пропускаем
        else:
            title = text[:200]
        if bare in seen:
            continue
        seen.add(bare)
        dom = reg_domain(bare)
        if SOCIAL_HINT.search(bare):
            continue  # соцсети собираются отдельно
        item = {"title": title, "url": bare}
        if dom and dom == base_dom:
            # пропускаем голую главную и совсем короткие пути
            path = urllib.parse.urlparse(bare).path.strip("/")
            if len(path) < 2:
                continue
            content.append(item)
        else:
            external.append(item)
    return {"content": content[:70], "external": external[:30]}


def parse_social_links(markup):
    found = {}
    for match in re.finditer(r'href=["\']([^"\']+)["\']', markup, re.I):
        url = match.group(1)
        m = SOCIAL_HINT.search(url)
        if not m:
            continue
        domain = m.group(1).lower().replace("www.", "")
        # короткое имя площадки
        name = {
            "t.me": "Telegram", "telegram.me": "Telegram", "vk.com": "VK",
            "youtube.com": "YouTube", "youtu.be": "YouTube", "dzen.ru": "Дзен",
            "zen.yandex": "Дзен", "rutube.ru": "RuTube", "ok.ru": "Одноклассники",
            "instagram.com": "Instagram", "facebook.com": "Facebook", "linkedin.com": "LinkedIn",
        }.get(domain, domain)
        clean = url.split("?")[0].rstrip("/")
        if name not in found:
            found[name] = clean
    return [f"{name}: {url}" for name, url in found.items()]


def parse_emails(markup):
    emails = set()
    for match in re.finditer(r"mailto:([^\"'?>\s]+)", markup, re.I):
        emails.add(match.group(1).strip().lower())
    for match in re.finditer(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", markup):
        addr = match.group(0).lower()
        if not re.search(r"\.(png|jpg|jpeg|gif|svg|webp|js|css)$", addr):
            if not addr.startswith(("example@", "name@", "mail@example", "test@")):
                emails.add(addr)
    return sorted(emails)[:10]


def parse_phones(markup):
    phones = set()
    # 1) Надёжнее всего — ссылки tel:
    for match in re.finditer(r'tel:([+\d\s\-\(\)]{10,})', markup, re.I):
        digits = re.sub(r"\D", "", match.group(1))
        if len(digits) == 11 and digits[0] in "78":
            phones.add("+7" + digits[1:])
    # 2) Номера в тексте — но только с разделителями (иначе ловим ID из вёрстки)
    pat = re.compile(r"(?<!\d)(?:\+7|8)[\s\-]*\(?\d{3}\)?[\s\-]+\d{3}[\s\-]*\d{2}[\s\-]*\d{2}(?!\d)")
    for match in pat.finditer(markup):
        raw = match.group(0)
        if not re.search(r"[\s\-()]", raw):
            continue
        digits = re.sub(r"\D", "", raw)
        if len(digits) == 11 and digits[0] in "78":
            phones.add("+7" + digits[1:])
    # убираем явные плейсхолдеры вида +79999999999 / +70000000000
    phones = {p for p in phones if len(set(p[2:])) > 2}
    return sorted(phones)[:6]


def image_dimensions(data):
    """Достаём ширину/высоту картинки прямо из байтов, без сторонних библиотек."""
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            w, h = struct.unpack(">II", data[16:24])
            return w, h
        if data[:6] in (b"GIF87a", b"GIF89a"):
            w, h = struct.unpack("<HH", data[6:10])
            return w, h
        if data[:2] == b"\xff\xd8":  # JPEG
            i, n = 2, len(data)
            while i < n - 9:
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return w, h
                seg = struct.unpack(">H", data[i + 2:i + 4])[0]
                i += 2 + seg
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            chunk = data[12:16]
            if chunk == b"VP8X":
                w = (data[24] | (data[25] << 8) | (data[26] << 16)) + 1
                h = (data[27] | (data[28] << 8) | (data[29] << 16)) + 1
                return w, h
            if chunk == b"VP8 ":
                w = struct.unpack("<H", data[26:28])[0] & 0x3FFF
                h = struct.unpack("<H", data[28:30])[0] & 0x3FFF
                return w, h
            if chunk == b"VP8L":
                b0, b1, b2, b3 = data[21], data[22], data[23], data[24]
                w = ((b1 & 0x3F) << 8 | b0) + 1
                h = ((b3 & 0x0F) << 10 | b2 << 2 | (b1 & 0xC0) >> 6) + 1
                return w, h
    except Exception:
        return None
    return None


def good_image(data):
    """Оставляем только нормальные картинки: не иконки, не тонкие полоски-баннеры."""
    dims = image_dimensions(data)
    if not dims:
        return False
    w, h = dims
    if w < 240 or h < 140:
        return False  # иконка/логотип
    ratio = w / h if h else 99
    if ratio > 4.5 or ratio < 0.22:
        return False  # тонкий баннер/разделитель
    return True


def parse_images(markup, base, key):
    markup = strip_noise(markup)
    items = []
    seen = set()
    for match in re.finditer(r'<img\s+[^>]*(?:data-src|data-lazy-src|src)=["\']([^"\']+)["\']', markup, re.I):
        src = abs_url(match.group(1), base)
        if not src.startswith("http") or src in seen:
            continue
        if re.search(
            r"sprite|icon|favicon|logo|blank|placeholder|loader|spacer|pixel|badge|qr|"
            r"app-?store|google-?play|play-?market|/vk|telegram|youtube|rutube|dzen|"
            r"whats|viber|facebook|/fb|/ok|button|/btn|arrow|\.svg($|\?)|data:image",
            src, re.I,
        ):
            continue
        seen.add(src)
        items.append(src)
    local = []
    for url in items[:16]:
        path = download_asset(url, key)
        if path:
            local.append(path)
        if len(local) >= 8:
            break
    return local


def download_asset(url, key):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen_with_ssl_fallback(req, timeout=8) as resp:
            ctype = resp.headers.get("content-type", "")
            if not ctype.startswith("image/"):
                return None
            data = resp.read(3_000_000)
        if not good_image(data):
            return None  # отсеиваем иконки, логотипы и баннеры-полоски
        ext = ".jpg"
        if "png" in ctype:
            ext = ".png"
        elif "webp" in ctype:
            ext = ".webp"
        elif "gif" in ctype:
            ext = ".gif"
        # стабильное имя по содержимому — не плодим дубликаты при повторных прогонах
        digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:16]
        filename = f"{key}-{digest}{ext}"
        path = ASSETS / filename
        path.write_bytes(data)
        return str(path.relative_to(ROOT))
    except Exception:
        return None


def collect_site(comp):
    result = {"summary": "", "content": [], "external": [], "images": [],
              "social": [], "emails": [], "phones": [], "errors": []}
    try:
        markup = request_text(comp["site"])
        title, desc = parse_title_description(markup)
        result["summary"] = clean_text(" - ".join([x for x in [title, desc] if x]))[:450]
        links = parse_links(markup, comp["site"])
        result["content"] = links["content"]
        result["external"] = links["external"]
        result["images"] = parse_images(markup, comp["site"], comp["key"])
        result["social"] = parse_social_links(markup)
        result["emails"] = parse_emails(markup)
        result["phones"] = parse_phones(markup)
        # обходим несколько доп. страниц; картинки тянем только пока их мало (это самый долгий шаг)
        for extra in discover_extra_public_pages(markup, comp["site"])[:7]:
            try:
                page = request_text(extra, timeout=8)
                more = parse_links(page, extra)
                result["content"].extend(more["content"][:14])
                result["external"].extend(more["external"][:8])
                if len(result["images"]) < 8:
                    result["images"].extend(parse_images(page, extra, comp["key"])[:3])
                result["social"].extend(parse_social_links(page))
                result["emails"].extend(parse_emails(page))
                result["phones"].extend(parse_phones(page))
            except Exception:
                pass
        result["content"] = unique_items(result["content"], "url")[:70]
        result["external"] = unique_items(result["external"], "url")[:30]
        result["images"] = list(dict.fromkeys(result["images"]))[:14]
        result["social"] = list(dict.fromkeys(result["social"]))[:12]
        result["emails"] = list(dict.fromkeys(result["emails"]))[:10]
        result["phones"] = list(dict.fromkeys(result["phones"]))[:6]
    except Exception as exc:
        result["errors"].append(f"Сайт не собрался: {exc}")
    return result


def unique_items(items, key):
    seen = set()
    out = []
    for item in items:
        value = item.get(key) if isinstance(item, dict) else item
        if value in seen:
            continue
        seen.add(value)
        out.append(item)
    return out


def discover_extra_public_pages(markup, base):
    urls = []
    candidates = [
        "/sitemap.xml", "/sitemap_index.xml", "/rss", "/rss.xml", "/feed",
        "/blog/", "/blog", "/news/", "/news", "/events/", "/events",
        "/case/", "/cases/", "/cases", "/keysy/", "/press/", "/media/",
        "/updates/", "/release-notes/", "/changelog/", "/webinars/",
        "/about/", "/about", "/career/", "/vacancy/", "/jobs/", "/contacts/",
    ]
    for c in candidates:
        urls.append(abs_url(c, base))
    # ссылки на разделы прямо со страницы
    for match in re.finditer(r'<a\s+[^>]*href=["\']([^"\']+)["\']', markup, re.I):
        u = abs_url(match.group(1), base)
        if u.startswith("http") and re.search(r"blog|news|case|keys|event|press|media|update|release|changelog|стат|кейс|новост", u, re.I):
            urls.append(u.split("#")[0])
    # из sitemap
    for match in re.finditer(r"<loc>(.*?)</loc>", markup, re.I | re.S):
        u = clean_text(match.group(1))
        if re.search(r"blog|news|article|post|case|events|press|media|tpost|update|release", u, re.I):
            urls.append(u)
    return list(dict.fromkeys(urls))


def collect_telegram(channel):
    if not channel:
        return {"posts": [], "subscribers": None, "errors": []}
    channel = channel.strip().replace("@", "")
    channel = re.sub(r"^https?://(t\.me|telegram\.me)/(s/)?", "", channel).split("/")[0]
    if not channel:
        return {"posts": [], "subscribers": None, "errors": []}
    url = f"https://t.me/s/{channel}"
    result = {"posts": [], "subscribers": None, "errors": []}
    try:
        markup = request_text(url)
        sub_match = re.search(r'class="tgme_channel_info_counter[^"]*"[^>]*>.*?class="counter_value"[^>]*>(.*?)</', markup, re.I | re.S)
        if sub_match:
            result["subscribers"] = clean_text(sub_match.group(1))
        for match in re.finditer(r'class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', markup, re.I | re.S):
            text = clean_text(re.sub(r"<br\s*/?>", "\n", match.group(1), flags=re.I))
            text = clean_text(re.sub(r"<[^>]+>", " ", text))
            if text:
                result["posts"].append({"title": text[:220], "url": url})
        result["posts"] = result["posts"][:12]
    except Exception as exc:
        result["errors"].append(f"Telegram не собрался: {exc}")
    return result


def parse_import_text(text):
    parsed = {comp["key"]: {"wordstat": {}, "spywords": {}, "social": {}} for comp in COMPETITORS}
    for raw_line in (text or "").splitlines():
        line = clean_text(raw_line)
        if not line:
            continue
        value = number_from(line)
        if value is None:
            continue
        nline = norm(line)
        metric_line = bool(re.search(r"top\s*\d+|топ\s*\d+|top-\d+|топ-\d+|telegram|телеграм|tg|vk|вк|вконтакте", nline))
        for comp in COMPETITORS:
            ckey = comp["key"]
            cname = norm(comp["name"])
            domain = norm(comp["domain"])
            mentions_comp = cname in nline or domain in nline or ckey in nline
            for query in comp["queries"]:
                nq = norm(query)
                if not metric_line and nq and (nline.startswith(nq) or f" {nq} " in f" {nline} "):
                    parsed[ckey]["wordstat"][query] = value
            if mentions_comp:
                is_yandex = bool(re.search(r"янд|yandex", nline))
                is_google = bool(re.search(r"google|гугл", nline))
                is_top50 = bool(re.search(r"top\s*50|топ\s*50|top-50|топ-50", nline))
                is_top10 = bool(re.search(r"top\s*10|топ\s*10|top-10|топ-10", nline))
                if is_yandex and is_top50:
                    parsed[ckey]["spywords"]["yandex_top50"] = value
                elif is_yandex and is_top10:
                    parsed[ckey]["spywords"]["yandex_top10"] = value
                elif is_google and is_top50:
                    parsed[ckey]["spywords"]["google_top50"] = value
                elif is_google and is_top10:
                    parsed[ckey]["spywords"]["google_top10"] = value
                elif re.search(r"telegram|телеграм|tg", nline):
                    parsed[ckey]["social"]["telegram"] = value
                elif re.search(r"vk|вк|вконтакте", nline):
                    parsed[ckey]["social"]["vk"] = value
    return parsed


def parse_manual_metrics(manual_metrics):
    parsed = {comp["key"]: {"spywords": {}, "social": {}} for comp in COMPETITORS}
    manual_metrics = manual_metrics or {}
    for comp in COMPETITORS:
        row = manual_metrics.get(comp["key"], {}) or {}
        for key in ["yandex_top50", "yandex_top10", "google_top50", "google_top10", "search_traffic_yandex", "search_traffic_google", "unique_urls_yandex", "unique_urls_google"]:
            if row.get(key) not in (None, ""):
                try:
                    parsed[comp["key"]]["spywords"][key] = int(row[key])
                except Exception:
                    pass
        for key in ["telegram", "vk"]:
            if row.get(key) not in (None, ""):
                try:
                    parsed[comp["key"]]["social"][key] = int(row[key])
                except Exception:
                    pass
    return parsed


def collect_authorized_text(auth):
    auth = auth or {}
    chunks = []
    errors = []
    targets = [
        ("SpyWords", auth.get("spywordsUrl"), auth.get("spywordsCookie")),
        ("Вордстат", auth.get("wordstatUrl"), auth.get("wordstatCookie")),
    ]
    for label, url, cookie in targets:
        if not url:
            continue
        headers = {}
        if cookie:
            headers["Cookie"] = cookie
        if auth.get("apiToken"):
            headers["Authorization"] = auth["apiToken"] if auth["apiToken"].lower().startswith("bearer ") else "Bearer " + auth["apiToken"]
        try:
            text = request_text(url, timeout=25, extra_headers=headers)
            chunks.append(f"\n\n### {label} authorized page {url}\n{text}")
        except Exception as exc:
            errors.append(f"{label}: авторизованный сбор не удался: {exc}")
    for url in auth.get("extraUrls", []) or []:
        try:
            text = request_text(url, timeout=20)
            chunks.append(f"\n\n### Extra URL {url}\n{text}")
        except Exception as exc:
            errors.append(f"Доп. URL {url}: не удалось собрать: {exc}")
    return "\n".join(chunks), errors


def _collect_one(comp, source):
    """Сетевой сбор по одному конкуренту (выполняется в отдельном потоке)."""
    comp = dict(comp)
    if source.get("site"):
        comp["site"] = source["site"]
    site_data = collect_site(comp)
    tg_data = collect_telegram(source.get("telegram", ""))
    return comp, site_data, tg_data


def merge_real_data(month, import_text, sources, manual_metrics=None, auth=None):
    from concurrent.futures import ThreadPoolExecutor

    auth_text, auth_errors = collect_authorized_text(auth)
    parsed = parse_import_text((import_text or "") + "\n" + auth_text)
    manual = parse_manual_metrics(manual_metrics)

    # параллельно тянем сеть по всем конкурентам — это в разы быстрее, чем по очереди
    with ThreadPoolExecutor(max_workers=len(COMPETITORS)) as pool:
        results = list(pool.map(
            lambda comp: _collect_one(comp, sources.get(comp["key"], {})),
            COMPETITORS,
        ))

    items = []
    for comp, site_data, tg_data in results:
        key = comp["key"]
        data = CompetitorData(key, comp["name"], comp["domain"], comp["site"])
        data.wordstat.update(parsed[key]["wordstat"])
        data.spywords.update(parsed[key]["spywords"])
        data.spywords.update(manual[key]["spywords"])
        social = parsed[key]["social"]
        social.update(manual[key]["social"])
        if social.get("telegram"):
            data.social.append(f"Telegram: {social['telegram']} подписчиков")
        if social.get("vk"):
            data.social.append(f"VK: {social['vk']} подписчиков")

        data.site_summary = site_data["summary"]
        data.content.extend(site_data["content"])
        data.external.extend(site_data.get("external", []))
        data.images.extend(site_data["images"])
        data.social.extend(site_data.get("social", []))
        data.emails.extend(site_data.get("emails", []))
        data.phones.extend(site_data.get("phones", []))
        data.errors.extend(site_data["errors"])

        if tg_data["subscribers"]:
            data.social.append(f"Telegram: {tg_data['subscribers']} подписчиков")
        data.content.extend(tg_data["posts"])
        data.errors.extend(tg_data["errors"])
        data.errors.extend(auth_errors)
        items.append(data)
    return items


def asdict_data(items):
    out = []
    for item in items:
        out.append({
            "key": item.key,
            "name": item.name,
            "domain": item.domain,
            "site": item.site,
            "wordstat": item.wordstat,
            "spywords": item.spywords,
            "site_summary": item.site_summary,
            "content": item.content,
            "external": item.external,
            "social": item.social,
            "media": item.media,
            "emails": item.emails,
            "phones": item.phones,
            "events": item.events,
            "updates": item.updates,
            "jobs": item.jobs,
            "images": item.images,
            "errors": item.errors,
        })
    return out


def fmt(value):
    if value is None or value == "":
        return "-"
    try:
        return f"{int(value):,}".replace(",", " ")
    except Exception:
        return str(value)


def e(value):
    return html.escape(str(value or ""))


def bar_chart(title, pairs, color="#4f77ff", unit=""):
    """Простой горизонтальный bar-chart на чистом SVG, без зависимостей."""
    pairs = [(label, val) for label, val in pairs if val]
    if not pairs:
        return ""
    maxv = max(v for _, v in pairs) or 1
    row_h, label_w, chart_w = 30, 150, 540
    bar_max = chart_w - label_w - 60
    height = len(pairs) * row_h + 16
    rows = []
    y = 8
    for label, v in pairs:
        w = int(bar_max * v / maxv) if maxv else 0
        rows.append(f'<text x="0" y="{y+15}" font-size="12" fill="#333">{e(str(label)[:22])}</text>')
        rows.append(f'<rect x="{label_w}" y="{y+3}" width="{max(w,2)}" height="18" rx="3" fill="{color}"/>')
        rows.append(f'<text x="{label_w+max(w,2)+6}" y="{y+16}" font-size="11" fill="#555">{fmt(v)}{e(unit)}</text>')
        y += row_h
    return (f'<div class="chart"><b>{e(title)}</b>'
            f'<svg viewBox="0 0 {chart_w} {height}" width="100%" preserveAspectRatio="xMinYMin meet">'
            f'{"".join(rows)}</svg></div>')


def render_analytics_html(items):
    content_pairs = [(i.name, len(i.content)) for i in items]
    social_pairs = [(i.name, len(list(dict.fromkeys(i.social)))) for i in items]
    media_pairs = [(i.name, len(i.images)) for i in items]
    contact_pairs = [(i.name, len(set(i.emails)) + len(set(i.phones))) for i in items]
    wordstat_pairs = sorted(
        [(k, v) for i in items for k, v in i.wordstat.items()],
        key=lambda x: x[1], reverse=True,
    )[:12]
    visibility_pairs = sorted(
        [(i.name, (i.spywords.get("yandex_top50") or 0) + (i.spywords.get("google_top50") or 0)) for i in items],
        key=lambda x: x[1], reverse=True,
    )
    charts = [
        bar_chart("Объём публичного контента (материалов найдено)", content_pairs, "#4f77ff", " шт"),
        bar_chart("Соцсети и каналы (площадок найдено)", social_pairs, "#7a5300", " шт"),
        bar_chart("Медиа собрано (картинок)", media_pairs, "#14753f", " шт"),
        bar_chart("Контакты найдено (email+тел.)", contact_pairs, "#a52b2b", " шт"),
        bar_chart("Бренд-трафик (Вордстат, показы/мес)", wordstat_pairs, "#e51b1b"),
        bar_chart("Видимость TOP-50 (Яндекс+Google)", visibility_pairs, "#4285f4"),
    ]
    charts = [c for c in charts if c]
    if not charts:
        return ""
    return ('<section id="analytics"><h2>Аналитика</h2>'
            '<p>Графики строятся автоматически по собранным данным. Чем больше вставлено выгрузок '
            'SpyWords/Вордстата, тем больше числовых графиков появится.</p>'
            f'<div class="charts">{"".join(charts)}</div></section>')


def render_report_html(month, items):
    month_label = MONTHS.get(month, month)
    date = time.strftime("%d.%m.%Y, %H:%M")
    toc = "".join(f'<a href="#{item.key}">{e(item.name)}</a>' for item in items)
    body = f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><title>{e(month_label)} - мониторинг</title>
<style>
body{{font-family:Arial,Helvetica,sans-serif;color:#202020;background:#fff;margin:0}}
.page{{max-width:980px;margin:0 auto;padding:34px 42px}}
.chrome{{display:grid;grid-template-columns:1fr 1fr 1fr;margin-bottom:28px;font-family:Georgia,serif;font-size:14px}}
.chrome div:nth-child(2){{text-align:center}}.chrome div:nth-child(3){{text-align:right;font-family:Arial;font-size:12px;color:#777}}
h1{{font-size:25px;margin:0 0 22px}}h2{{font-size:32px;color:#4f77ff;margin:28px 0 16px}}h2.red{{color:#e30000}}
.toc{{border:1px solid #d8dbe3;border-radius:8px;padding:18px 20px;width:240px;margin-bottom:24px}}.toc b{{display:block;border-bottom:1px solid #e6e8ef;padding-bottom:12px;margin-bottom:12px}}.toc a{{display:block;color:#246bff;text-decoration:none;line-height:1.55}}
table{{border-collapse:collapse;width:100%;font-size:11px;margin:12px 0 18px;table-layout:fixed}}th,td{{border:1px solid #dfe3ec;padding:8px;vertical-align:top}}th{{background:#f3f5fb;color:#6d7891;font-weight:500;text-align:center}}td{{text-align:center}}.left{{text-align:left}}
.yandex{{color:#e51b1b;font-size:20px}}.google{{color:#4285f4;font-size:20px}}.link{{color:#8d4bd6}}p{{line-height:1.55}}ol{{line-height:1.55}}
.thumbs{{display:flex;gap:14px;flex-wrap:wrap;margin:10px 0 18px}}.thumbs img{{max-width:300px;max-height:220px;width:auto;height:auto;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.12)}}
.warn{{color:#9a5700;background:#fff7e8;padding:10px;border:1px solid #f1d39b;border-radius:6px}}
.charts{{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:16px 0 26px}}.chart{{border:1px solid #e6e8ef;border-radius:10px;padding:14px 16px;background:#fbfcff}}.chart b{{display:block;margin-bottom:8px;font-size:14px;color:#33415c}}
.contacts a{{color:#246bff;text-decoration:none}}
@media print{{.page{{padding:0}}@page{{margin:14mm 16mm}}.charts{{grid-template-columns:1fr 1fr}}}}
@media (max-width:760px){{.charts{{grid-template-columns:1fr}}}}
</style></head><body><div class="page">
<div class="chrome"><div>{e(date)}</div><div>Wiki</div><div>Обновлено {e(time.strftime("%d.%m.%Y"))}</div></div>
<h1>{e(month_label)} - Мониторинг активности конкурентов</h1>
<div class="toc"><b>Содержание страницы</b><a href="#analytics">Аналитика</a>{toc}<a href="#summary">Вывод:</a></div>
<p class="warn">Отчёт содержит только реально загруженные/собранные данные. SpyWords и Вордстат не выдумываются: для них нужна выгрузка, скриншот, API или авторизованный сбор.</p>
"""
    body += render_analytics_html(items)
    for item in items:
        red = " red" if item.key == "mdaudit" else ""
        y50 = item.spywords.get("yandex_top50")
        y10 = item.spywords.get("yandex_top10")
        g50 = item.spywords.get("google_top50")
        g10 = item.spywords.get("google_top10")
        wordstat = "".join(f"<p>«{e(k)}» - {fmt(v)} показов в месяц</p>" for k, v in item.wordstat.items()) or "<p>Реальная выгрузка Вордстата не загружена.</p>"
        content = "".join(f'<li>{e(x.get("title", ""))} <span class="link">{e(x.get("url", ""))}</span></li>' for x in item.content) or "<li>Публичный контент автоматически не найден.</li>"
        external = "".join(f'<li>{e(x.get("title", ""))} <span class="link">{e(x.get("url", ""))}</span></li>' for x in item.external)
        social_list = list(dict.fromkeys(item.social))
        social = "".join(f'<li><a href="{e(x.split(": ",1)[-1])}" target="_blank">{e(x)}</a></li>' if ": http" in x else f"<li>{e(x)}</li>" for x in social_list) or "<li>Данные соцсетей не загружены.</li>"
        contacts_list = [f'<a href="mailto:{e(a)}">{e(a)}</a>' for a in dict.fromkeys(item.emails)]
        contacts_list += [f'<a href="tel:{e(p)}">{e(p)}</a>' for p in dict.fromkeys(item.phones)]
        contacts = "".join(f"<li>{c}</li>" for c in contacts_list)
        errors = "".join(f"<li>{e(x)}</li>" for x in item.errors)
        images = "".join(
            f'<img src="../{e(path[len("output/"):] if path.startswith("output/") else path)}" alt="{e(item.name)}" loading="lazy">'
            for path in item.images[:12]
        )
        body += f"""
<section id="{e(item.key)}">
<h2 class="{red.strip()}">{e(item.name)}</h2>
<p><b>Показатели сайта:</b></p>
<table><thead><tr><th>Поисковая система</th><th>Запросов в TOP-50</th><th>Запросов в TOP-10</th><th>Трафик из поиска</th><th>Уникальных URL</th></tr></thead>
<tbody><tr><td><span class="yandex">Яндекс</span></td><td>{fmt(y50)}</td><td>{fmt(y10)}</td><td>{fmt(item.spywords.get("search_traffic_yandex"))}</td><td>{fmt(item.spywords.get("unique_urls_yandex"))}</td></tr>
<tr><td><span class="google">Google</span></td><td>{fmt(g50)}</td><td>{fmt(g10)}</td><td>{fmt(item.spywords.get("search_traffic_google"))}</td><td>{fmt(item.spywords.get("unique_urls_google"))}</td></tr></tbody></table>
<p>Анализ домена <span class="link">{e(item.domain)}</span></p>
<table><thead><tr><th>Детальные таблицы SpyWords</th></tr></thead><tbody><tr><td class="left">Детальная таблица/скриншот SpyWords не загружены. Загрузите экспорт или скриншоты, либо подключите авторизованный сбор.</td></tr></tbody></table>
<p><b>Вордстат:</b></p>{wordstat}
<p><b>Контент:</b></p><ol>{content}</ol>
<p><b>Соц. сети:</b></p><ol class="contacts">{social}</ol>
<p><b>Сторонние ресурсы (упоминания на других доменах):</b></p>{('<ol>'+external+'</ol>') if external else '<p>Внешних ссылок не найдено автоматически.</p>'}
<p><b>Email / контакты:</b></p>{('<ol class="contacts">'+contacts+'</ol>') if contacts else '<p>Публичные контакты не найдены автоматически.</p>'}
<p><b>Мероприятия:</b></p><p>Не загружено автоматически.</p>
<p><b>Обновления в сервисе:</b></p><p>{e(item.site_summary) if item.site_summary else "Не найдено автоматически."}</p>
<p><b>Вакансии:</b></p><p>Не загружено автоматически.</p>
{('<p><b>Медиа:</b></p><div class="thumbs">'+images+'</div>') if images else ''}
{('<p><b>Ошибки сбора:</b></p><ol>'+errors+'</ol>') if errors else ''}
</section>
"""
    body += render_summary_html(items)
    body += "</div></body></html>"
    return body


def render_summary_html(items):
    wordstat = []
    visibility = []
    for item in items:
        for key, value in item.wordstat.items():
            wordstat.append((key, value))
        total = (item.spywords.get("yandex_top50") or 0) + (item.spywords.get("google_top50") or 0)
        if total:
            visibility.append((item.name, total))
    wordstat.sort(key=lambda x: x[1], reverse=True)
    visibility.sort(key=lambda x: x[1], reverse=True)
    wordstat_html = "".join(f"<li>«{e(k)}» - {fmt(v)}</li>" for k, v in wordstat) or "<li>Вордстат не загружен.</li>"
    visibility_html = "".join(f"<li>{e(k)} - {fmt(v)}</li>" for k, v in visibility) or "<li>SpyWords не загружен.</li>"
    return f"""
<section id="summary"><h2>Вывод:</h2>
<ol>
<li>Отчёт построен только на реальных данных, которые удалось получить из публичных источников или вставить из выгрузок.</li>
<li>Если SpyWords/Вордстат не загружены, числовой вывод по видимости и бренд-трафику не определяется.</li>
</ol>
<p><b>Бренд трафик:</b></p><ol>{wordstat_html}</ol>
<p><b>Видимость TOP-50 Яндекс + Google:</b></p><ol>{visibility_html}</ol>
</section>
"""


def setup_fonts():
    if colors is None:
        return "Helvetica"
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ]
    for path in candidates:
        if Path(path).exists():
            try:
                pdfmetrics.registerFont(TTFont("MonitorFont", path))
                return "MonitorFont"
            except Exception:
                pass
    return "Helvetica"


def render_pdf(month, items, pdf_path):
    if colors is None:
        raise RuntimeError("reportlab is not installed")
    font = setup_fonts()
    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=14 * mm, bottomMargin=14 * mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="RuTitle", parent=styles["Title"], fontName=font, fontSize=18, leading=22, alignment=0))
    styles.add(ParagraphStyle(name="RuH2", parent=styles["Heading2"], fontName=font, fontSize=22, leading=26, textColor=colors.HexColor("#4f77ff")))
    styles.add(ParagraphStyle(name="RuBody", parent=styles["BodyText"], fontName=font, fontSize=10.5, leading=14))
    styles.add(ParagraphStyle(name="RuSmall", parent=styles["BodyText"], fontName=font, fontSize=8.5, leading=11, textColor=colors.HexColor("#666666")))
    story = [Paragraph(f"{MONTHS.get(month, month)} - Мониторинг активности конкурентов", styles["RuTitle"]), Spacer(1, 8)]
    story.append(Paragraph("Отчёт содержит только реально загруженные/собранные данные. SpyWords и Вордстат не выдумываются.", styles["RuSmall"]))
    story.append(Spacer(1, 10))
    for item in items:
        story.append(Paragraph(item.name, styles["RuH2"]))
        table_data = [
            ["Поисковая система", "TOP-50", "TOP-10", "Трафик", "URL"],
            ["Яндекс", fmt(item.spywords.get("yandex_top50")), fmt(item.spywords.get("yandex_top10")), fmt(item.spywords.get("search_traffic_yandex")), fmt(item.spywords.get("unique_urls_yandex"))],
            ["Google", fmt(item.spywords.get("google_top50")), fmt(item.spywords.get("google_top10")), fmt(item.spywords.get("search_traffic_google")), fmt(item.spywords.get("unique_urls_google"))],
        ]
        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), font),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f5fb")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dfe3ec")),
            ("ALIGN", (1, 1), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.extend([table, Spacer(1, 8)])
        story.append(Paragraph(f"Анализ домена {item.domain}", styles["RuBody"]))
        if item.wordstat:
            story.append(Paragraph("Вордстат:", styles["RuBody"]))
            story.append(ListFlowable([ListItem(Paragraph(f"«{k}» - {fmt(v)} показов в месяц", styles["RuBody"])) for k, v in item.wordstat.items()], bulletType="bullet"))
        else:
            story.append(Paragraph("Вордстат: реальная выгрузка не загружена.", styles["RuBody"]))
        if item.content:
            story.append(Paragraph("Контент:", styles["RuBody"]))
            story.append(ListFlowable([ListItem(Paragraph(f"{x.get('title', '')} {x.get('url', '')}", styles["RuBody"])) for x in item.content[:10]], bulletType="1"))
        else:
            story.append(Paragraph("Контент: публично не найден автоматически.", styles["RuBody"]))
        if item.social:
            story.append(Paragraph("Соц. сети:", styles["RuBody"]))
            story.append(ListFlowable([ListItem(Paragraph(x, styles["RuBody"])) for x in item.social], bulletType="1"))
        if item.images:
            imgs = []
            for rel in item.images[:4]:
                path = ROOT / rel
                if path.exists():
                    try:
                        imgs.append(Image(str(path), width=40 * mm, height=30 * mm))
                    except Exception:
                        pass
            if imgs:
                story.extend([Paragraph("Медиа:", styles["RuBody"]), Table([imgs])])
        story.append(Spacer(1, 14))
    story.append(PageBreak())
    story.append(Paragraph("Вывод:", styles["RuH2"]))
    story.append(Paragraph("Финальный аналитический вывод должен строиться только по загруженным метрикам. Если закрытые метрики не загружены, лидер по SpyWords/Вордстату не определяется.", styles["RuBody"]))
    doc.build(story)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/":
            path = "/index.html"
        if path.startswith("/output/"):
            file_path = ROOT / path.lstrip("/")
        else:
            file_path = STATIC / path.lstrip("/")
        if file_path.is_dir():
            file_path = file_path / "index.html"
        if not file_path.exists():
            self.send_error(404)
            return
        ctype = "text/html; charset=utf-8"
        if file_path.suffix == ".pdf":
            ctype = "application/pdf"
        elif file_path.suffix in (".jpg", ".jpeg"):
            ctype = "image/jpeg"
        elif file_path.suffix == ".png":
            ctype = "image/png"
        elif file_path.suffix == ".json":
            ctype = "application/json; charset=utf-8"
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        # запрещаем кеширование, чтобы браузер не показывал старую версию страницы
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        try:
            if self.path == "/api/run":
                payload = self.read_json()
                month = payload.get("month", "jun")
                import_text = payload.get("importText", "")
                sources = payload.get("sources", {})
                manual_metrics = payload.get("manualMetrics", {})
                auth = payload.get("auth", {})
                state = read_state()
                state["sources"] = sources
                write_state(state)
                items = merge_real_data(month, import_text, sources, manual_metrics, auth)
                stamp = time.strftime("%Y%m%d-%H%M%S")
                base = f"{month}-{stamp}"
                html_report = render_report_html(month, items)
                html_path = REPORTS / f"{base}.html"
                pdf_path = REPORTS / f"{base}.pdf"
                json_path = REPORTS / f"{base}.json"
                html_path.write_text(html_report, "utf-8")
                json_path.write_text(json.dumps(asdict_data(items), ensure_ascii=False, indent=2), "utf-8")
                pdf_error = None
                try:
                    render_pdf(month, items, pdf_path)
                except Exception as exc:
                    pdf_error = str(exc)
                state = read_state()
                state.setdefault("runs", {})[base] = {
                    "month": month,
                    "html": str(html_path.relative_to(ROOT)),
                    "pdf": str(pdf_path.relative_to(ROOT)) if pdf_path.exists() else None,
                    "json": str(json_path.relative_to(ROOT)),
                    "created": stamp,
                }
                write_state(state)
                self.send_json({
                    "ok": True,
                    "report": state["runs"][base],
                    "pdfError": pdf_error,
                    "data": asdict_data(items),
                })
                return
            if self.path == "/api/state":
                self.send_json(read_state())
                return
            self.send_error(404)
        except Exception as exc:
            traceback.print_exc()
            self.send_json({"ok": False, "error": str(exc)}, 500)


def main():
    ensure_dirs()
    import threading
    import webbrowser

    start_port = int(os.environ.get("PORT", "8787"))
    server = None
    port = start_port
    # если порт занят (старый сервер ещё работает) — берём следующий свободный
    for candidate in range(start_port, start_port + 20):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", candidate), Handler)
            port = candidate
            break
        except OSError:
            continue
    if server is None:
        print("Не удалось занять ни один порт в диапазоне "
              f"{start_port}-{start_port + 19}. Закройте старое окно программы и попробуйте снова.")
        return

    url = f"http://127.0.0.1:{port}"
    print(f"Marketing monitor: {url}")
    if port != start_port:
        print(f"(порт {start_port} был занят — использую {port})")
    # открываем браузер сами, на правильном порту
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлено.")


if __name__ == "__main__":
    main()
