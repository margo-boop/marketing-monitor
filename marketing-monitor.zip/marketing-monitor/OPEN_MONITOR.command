#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# браузер откроет сам app.py на свободном порту
./run.sh
